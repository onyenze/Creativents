const mongoose = require('mongoose');

const ticketSchema = mongoose.Schema({
    email :{
        type:String,
        required: [true, 'ticketQuantity is Required']
    },
    ticketQuantity:{
        type:Number,
        required: [true, 'ticketQuantity is Required']
    },
    eventPrice: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventDescription: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventName: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventVenue: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventDate: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventTime: {
        type:mongoose.Schema.Types.ObjectId,
        ref:"event"
    },
    eventImages:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"event",
    },
    link: {
       type: mongoose.Schema.Types.ObjectId,
       ref: 'event'
   },
    saleDate: { type: Date, default: Date.now }
}, {timestamps: true});

const ticketModel = mongoose.model('ticket', ticketSchema);
module.exports = ticketModel